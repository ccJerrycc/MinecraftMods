package gravitycommand.imixin;

import net.minecraft.entity.Entity;

import java.util.Set;

public interface IServerWorldMixin {
    Set<Entity> getMasses();
}