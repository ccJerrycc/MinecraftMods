package gravitycommand.imixin;

public interface IEntityMixin {
    double getMass();

    void setMass(double mass);
}