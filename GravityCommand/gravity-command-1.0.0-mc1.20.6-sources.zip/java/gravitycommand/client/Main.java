package gravitycommand.client;

import gravitycommand.PlayerVelocityAddS2CPacket;
import gravitycommand.PlayerYawAddS2CPacket;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.network.ClientPlayerEntity;

public class Main implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(PlayerVelocityAddS2CPacket.ID, (payload, context) -> context.player().addVelocity(payload.getVelocityX(), payload.getVelocityY(), payload.getVelocityZ()));
        ClientPlayNetworking.registerGlobalReceiver(PlayerYawAddS2CPacket.ID, (payload, context) -> {
            ClientPlayerEntity playerEntity = context.player();

            playerEntity.setYaw(playerEntity.getYaw() + payload.getYaw());
            playerEntity.prevYaw += payload.getYaw();
        });
    }
}