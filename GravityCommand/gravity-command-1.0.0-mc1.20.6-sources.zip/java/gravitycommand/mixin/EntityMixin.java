package gravitycommand.mixin;

import gravitycommand.PlayerVelocityAddS2CPacket;
import gravitycommand.PlayerYawAddS2CPacket;
import gravitycommand.imixin.IEntityMixin;
import gravitycommand.imixin.IServerWorldMixin;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

@Mixin(Entity.class)
public abstract class EntityMixin implements IEntityMixin {
    private double mass = 0;

    @Shadow public abstract World getWorld();

    @Shadow public abstract Set<String> getCommandTags();

    @Shadow public abstract Vec3d getPos();

    @Shadow public abstract Vec3d getVelocity();

    @Shadow public abstract void addVelocity(Vec3d velocity);

    @Shadow public abstract void limitFallDistance();

    @Shadow public abstract void refreshPositionAndAngles(double x, double y, double z, float yaw, float pitch);

    @Shadow public abstract void setHeadYaw(float headYaw);

    @Shadow public abstract float getPitch();

    @Shadow public abstract float getYaw();

    @Inject(at = @At("HEAD"), method = "tick()V")
    private void Itick(CallbackInfo ci) {
        if (!this.getWorld().isClient && !this.getCommandTags().contains("gravitycommand")) {
            Vec3d pos = this.getPos();
            Vec3d velocity = this.getVelocity();
            Vec3d gravity = Vec3d.ZERO;
            for (Entity entity : ((IServerWorldMixin) this.getWorld()).getMasses())
                if ((Object) this != entity) {
                    Vec3d pos1 = entity.getPos().subtract(pos);
                    double lenSq = pos1.lengthSquared() + 1;

                    gravity = gravity.add(pos1.multiply(((IEntityMixin) entity).getMass() / Math.sqrt(lenSq * lenSq * lenSq)));
                }
            float yaw = (float) (velocity.crossProduct(gravity).y / (1 + velocity.lengthSquared()) * 180 / Math.PI);

            this.addVelocity(gravity);
            this.limitFallDistance();
            this.refreshPositionAndAngles(pos.x, pos.y, pos.z, this.getYaw() - yaw, this.getPitch());
            this.setHeadYaw(this.getYaw() - yaw);
            if ((Object) this instanceof ServerPlayerEntity) {
                ServerPlayNetworking.send((ServerPlayerEntity) (Object) this, new PlayerVelocityAddS2CPacket(gravity));
                ServerPlayNetworking.send((ServerPlayerEntity) (Object) this, new PlayerYawAddS2CPacket(-yaw));
            }
        }
    }

    @Inject(at = @At("HEAD"), method = "readNbt(Lnet/minecraft/nbt/NbtCompound;)V")
    private void IreadNbt(NbtCompound nbt, CallbackInfo ci) {
        this.setMass(nbt.getDouble("mass"));
    }

    @Inject(at = @At("HEAD"), method = "writeNbt(Lnet/minecraft/nbt/NbtCompound;)Lnet/minecraft/nbt/NbtCompound;")
    private void IwriteNbt(NbtCompound nbt, CallbackInfoReturnable<NbtCompound> cir) {
        if (this.mass != 0)
            nbt.putDouble("mass", this.mass);
    }

    @Override
    public double getMass() {
        return this.mass;
    }

    @Override
    public void setMass(double mass) {
        this.mass = mass;
        if (mass == 0)
            ((IServerWorldMixin) this.getWorld()).getMasses().remove((Entity) (Object) this);
        else
            ((IServerWorldMixin) this.getWorld()).getMasses().add((Entity) (Object) this);
    }
}