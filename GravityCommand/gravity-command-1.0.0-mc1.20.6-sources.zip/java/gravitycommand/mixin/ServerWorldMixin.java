package gravitycommand.mixin;

import gravitycommand.imixin.IServerWorldMixin;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;

import java.util.HashSet;
import java.util.Set;

@Mixin(ServerWorld.class)
public abstract class ServerWorldMixin implements IServerWorldMixin {
    private final Set<Entity> masses = new HashSet<>();

    @Override
    public Set<Entity> getMasses() {
        return this.masses;
    }
}