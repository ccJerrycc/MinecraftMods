package gravitycommand;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class PlayerVelocityAddS2CPacket implements CustomPayload {
    public static final CustomPayload.Id<PlayerVelocityAddS2CPacket> ID = new CustomPayload.Id<>(new Identifier("add_player_motion"));
    public static final PacketCodec<RegistryByteBuf, PlayerVelocityAddS2CPacket> CODEC = CustomPayload.codecOf(PlayerVelocityAddS2CPacket::write, PlayerVelocityAddS2CPacket::new);
    private final double velocityX;
    private final double velocityY;
    private final double velocityZ;

    public PlayerVelocityAddS2CPacket(Vec3d velocity) {
        this.velocityX = velocity.x;
        this.velocityY = velocity.y;
        this.velocityZ = velocity.z;
    }

    private PlayerVelocityAddS2CPacket(RegistryByteBuf buf) {
        this.velocityX = buf.readDouble();
        this.velocityY = buf.readDouble();
        this.velocityZ = buf.readDouble();
    }

    private void write(RegistryByteBuf buf) {
        buf.writeDouble(this.velocityX);
        buf.writeDouble(this.velocityY);
        buf.writeDouble(this.velocityZ);
    }

    public double getVelocityX() {
        return this.velocityX;
    }

    public double getVelocityY() {
        return this.velocityY;
    }

    public double getVelocityZ() {
        return this.velocityZ;
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return PlayerVelocityAddS2CPacket.ID;
    }
}