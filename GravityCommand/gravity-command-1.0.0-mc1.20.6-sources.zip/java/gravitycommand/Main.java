package gravitycommand;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import gravitycommand.imixin.IEntityMixin;
import gravitycommand.imixin.IServerWorldMixin;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.command.DataCommandStorage;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class Main implements ModInitializer {
    public static final Identifier IDENTIFIER = new Identifier("gravitycommand");

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(PlayerVelocityAddS2CPacket.ID, PlayerVelocityAddS2CPacket.CODEC);
        PayloadTypeRegistry.playS2C().register(PlayerYawAddS2CPacket.ID, PlayerYawAddS2CPacket.CODEC);
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (((IEntityMixin) entity).getMass() != 0)
                ((IServerWorldMixin) world).getMasses().add(entity);
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            if (((IEntityMixin) entity).getMass() != 0)
                ((IServerWorldMixin) world).getMasses().remove(entity);
        });
        ServerEntityWorldChangeEvents.AFTER_ENTITY_CHANGE_WORLD.register((entity, entity1, world, world1) -> {
            if (((IEntityMixin) entity).getMass() != 0) {
                ((IServerWorldMixin) world).getMasses().remove(entity);
                ((IServerWorldMixin) world1).getMasses().add(entity1);
            }
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                CommandManager.literal("gravity").requires(source -> source.hasPermissionLevel(2)).
                    then(CommandManager.argument("target", EntityArgumentType.entity()).
                        then(CommandManager.literal("get").executes(context -> {
                                Entity target = EntityArgumentType.getEntity(context, "target");
                                double mass = ((IEntityMixin) target).getMass();
                                DataCommandStorage storage = context.getSource().getServer().getDataCommandStorage();
                                NbtCompound nbtCompound = storage.get(Main.IDENTIFIER);
                                nbtCompound.putDouble("mass", mass);

                                storage.set(Main.IDENTIFIER, nbtCompound);
                                context.getSource().sendFeedback(() -> Text.translatable("commands.gravity.get.success", target.getName(), mass), false);

                                return 1;
                            })).
                        then(CommandManager.literal("set").
                            then(CommandManager.argument("mass", DoubleArgumentType.doubleArg()).executes(context -> {
                                    Entity target = EntityArgumentType.getEntity(context, "target");
                                    double mass = DoubleArgumentType.getDouble(context, "mass");

                                    ((IEntityMixin) target).setMass(mass);
                                    context.getSource().sendFeedback(() -> Text.translatable("commands.gravity.set.success", target.getName(), mass), false);

                                    return 1;
                            })))))
            );
    }
}