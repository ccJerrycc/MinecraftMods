package gravitycommand;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public class PlayerYawAddS2CPacket implements CustomPayload {
    public static final CustomPayload.Id<PlayerYawAddS2CPacket> ID = new CustomPayload.Id<>(new Identifier("add_player_yaw"));
    public static final PacketCodec<RegistryByteBuf, PlayerYawAddS2CPacket> CODEC = CustomPayload.codecOf(PlayerYawAddS2CPacket::write, PlayerYawAddS2CPacket::new);
    private final float yaw;

    public PlayerYawAddS2CPacket(float yaw) {
        this.yaw = yaw;
    }

    private PlayerYawAddS2CPacket(RegistryByteBuf buf) {
        this.yaw = buf.readFloat();
    }

    private void write(RegistryByteBuf buf) {
        buf.writeFloat(this.yaw);
    }

    public float getYaw() {
        return this.yaw;
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return PlayerYawAddS2CPacket.ID;
    }
}