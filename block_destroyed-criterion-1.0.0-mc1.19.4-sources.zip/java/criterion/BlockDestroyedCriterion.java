package criterion;

import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import net.minecraft.advancement.criterion.AbstractCriterion;
import net.minecraft.advancement.criterion.AbstractCriterionConditions;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.NbtPredicate;
import net.minecraft.predicate.StatePredicate;
import net.minecraft.predicate.entity.AdvancementEntityPredicateDeserializer;
import net.minecraft.predicate.entity.AdvancementEntityPredicateSerializer;
import net.minecraft.predicate.entity.EntityPredicate;
import net.minecraft.predicate.entity.LocationPredicate;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public class BlockDestroyedCriterion extends AbstractCriterion<BlockDestroyedCriterion.Conditions> {
    final Identifier id;

    public BlockDestroyedCriterion(Identifier id) {
        this.id = id;
    }

    @Override
    public Identifier getId() {
        return this.id;
    }

    @Override
    protected Conditions conditionsFromJson(JsonObject jsonObject, EntityPredicate.Extended extended, AdvancementEntityPredicateDeserializer predicateDeserializer) {
        return new BlockDestroyedCriterion.Conditions(this.id, extended, BlockDestroyedCriterion.getBlock(jsonObject), BlockDestroyedCriterion.getTag(jsonObject), StatePredicate.fromJson(jsonObject.get("state")), NbtPredicate.fromJson(jsonObject.get("nbt")),LocationPredicate.fromJson(jsonObject.get("location")), ItemPredicate.fromJson(jsonObject.get("item")));
    }

    @Nullable
    private static Block getBlock(JsonObject root) {
        if (root.has("block")) {
            Identifier identifier = new Identifier(root.get("block").getAsString());

            return Registries.BLOCK.getOrEmpty(identifier).orElseThrow(() -> new JsonSyntaxException("Unknown block type '" + identifier + "'"));
        } else
            return null;
    }

    @Nullable
    private static TagKey<Block> getTag(JsonObject root) {
        if (root.has("tag")) {
            return TagKey.of(RegistryKeys.BLOCK, new Identifier(root.get("tag").getAsString()));
        } else
            return null;
    }

    public void trigger(ServerPlayerEntity player, BlockPos pos, BlockState state, @Nullable BlockEntity blockEntity, ItemStack stack) {
        this.trigger(player, conditions -> conditions.test(state, blockEntity, pos, player.getWorld(), stack));
    }

    public static class Conditions extends AbstractCriterionConditions {
        @Nullable
        private final Block block;
        @Nullable
        private final TagKey<Block> tag;
        private final StatePredicate state;
        private final NbtPredicate nbt;
        private final LocationPredicate location;
        private final ItemPredicate item;

        public Conditions(Identifier id, EntityPredicate.Extended entity, @Nullable Block block, @Nullable TagKey<Block> tag, StatePredicate state, NbtPredicate nbt, LocationPredicate location, ItemPredicate item) {
            super(id, entity);
            this.block = block;
            this.tag = tag;
            this.state = state;
            this.nbt = nbt;
            this.location = location;
            this.item = item;
        }

        public boolean test(BlockState state, @Nullable BlockEntity blockEntity, BlockPos pos, ServerWorld world, ItemStack stack) {
            return (this.block == null || state.isOf(block)) &&
                   (this.tag == null || state.isIn(tag)) &&
                   this.state.test(state) &&
                   (blockEntity == null || this.nbt.test(blockEntity.createNbtWithIdentifyingData())) &&
                   this.location.test(world, pos.getX(), pos.getY(), pos.getZ()) &&
                   this.item.test(stack);
        }

        @Override
        public JsonObject toJson(AdvancementEntityPredicateSerializer predicateSerializer) {
            JsonObject jsonObject = super.toJson(predicateSerializer);
            if (this.block != null)
                jsonObject.addProperty("block", Registries.BLOCK.getId(this.block).toString());
            if (this.tag != null)
                jsonObject.addProperty("tag", this.tag.id().toString());
            jsonObject.add("state", this.state.toJson());
            jsonObject.add("nbt", this.nbt.toJson());
            jsonObject.add("location", this.location.toJson());
            jsonObject.add("item", this.item.toJson());

            return jsonObject;
        }
    }
}