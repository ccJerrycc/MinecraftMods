package criterion;

import net.fabricmc.api.ModInitializer;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.util.Identifier;

public class Main implements ModInitializer {
    public static final BlockDestroyedCriterion BLOCK_DESTROYED = Criteria.register(new BlockDestroyedCriterion(new Identifier("block_destroyed")));

    @Override
    public void onInitialize() {}
}