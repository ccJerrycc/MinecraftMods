package motioncommand;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.DataCommandStorage;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class Main implements ModInitializer {
    public static final Identifier IDENTIFIER = new Identifier("motioncommand");

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                CommandManager.literal("motion").requires(source -> source.hasPermissionLevel(2)).
                    then(CommandManager.argument("target", EntityArgumentType.entity()).
                        then(CommandManager.literal("get").executes(context -> {
                                Entity target = EntityArgumentType.getEntity(context, "target");
                                Vec3d velocity = target.getVelocity();
                                DataCommandStorage storage = context.getSource().getServer().getDataCommandStorage();
                                NbtCompound nbtCompound = storage.get(Main.IDENTIFIER);
                                nbtCompound.putDouble("x", velocity.x);
                                nbtCompound.putDouble("y", velocity.y);
                                nbtCompound.putDouble("z", velocity.z);

                                storage.set(Main.IDENTIFIER, nbtCompound);
                                context.getSource().sendFeedback(() -> Text.translatable("commands.motion.get.success", target.getName(), velocity.toString()), false);

                                return 1;
                            })).
                        then(CommandManager.literal("set").
                            then(CommandManager.argument("x", DoubleArgumentType.doubleArg()).
                                then(CommandManager.argument("y", DoubleArgumentType.doubleArg()).
                                    then(CommandManager.argument("z", DoubleArgumentType.doubleArg()).executes(context -> {
                                            Entity target = EntityArgumentType.getEntity(context, "target");
                                            Vec3d velocity = new Vec3d(
                                                DoubleArgumentType.getDouble(context, "x"),
                                                DoubleArgumentType.getDouble(context, "y"),
                                                DoubleArgumentType.getDouble(context, "z")
                                            );

                                            target.setVelocity(velocity);
                                            target.velocityModified = true;
                                            target.limitFallDistance();
                                            context.getSource().sendFeedback(() -> Text.translatable("commands.motion.set.success", target.getName(), velocity.toString()), false);

                                            return 1;
                                        })))))))
            );
    }
}