package criterion;

import net.fabricmc.api.ModInitializer;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.util.Identifier;

public class Main implements ModInitializer {
    public static final ItemUsedCriterion ITEM_USED = Criteria.register(new ItemUsedCriterion(new Identifier("item_used")));

    @Override
    public void onInitialize() {}
}