package mc236303fix.mixin;

import net.minecraft.entity.mob.PathAwareEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(targets = "net.minecraft.entity.mob.SpiderEntity$AttackGoal")
public abstract class SpiderEntityMixin {
    @Redirect(at = @At(value = "INVOKE", target = "net/minecraft/entity/mob/PathAwareEntity.hasPassengers ()Z"), method = "canStart()Z")
    private boolean RhasPassengers(PathAwareEntity ins) {
        return false;
    }
}