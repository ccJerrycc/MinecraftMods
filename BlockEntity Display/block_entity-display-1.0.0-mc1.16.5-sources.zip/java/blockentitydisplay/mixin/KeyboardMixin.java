package blockentitydisplay.mixin;

import blockentitydisplay.Client;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.Keyboard;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.TranslatableText;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Keyboard.class)
public abstract class KeyboardMixin {
    @Shadow protected abstract void debugWarn(String key, Object... args);

    @Inject(at = @At(value = "RETURN", ordinal = 11), method = "processF3(I)Z")
    private void IprocessF3(CallbackInfoReturnable<Boolean> cir, @Local ChatHud chatHud) {
        chatHud.addMessage(new TranslatableText("debug.block_entity.help"));
    }

    @Inject(at = @At("TAIL"), method = "processF3(I)Z", cancellable = true)
    private void I2processF3(int key, CallbackInfoReturnable<Boolean> cir) {
        if (key == 56) {
            Client.showBlockEntity = !Client.showBlockEntity;
            this.debugWarn(Client.showBlockEntity ? "debug.block_entity.on" : "debug.block_entity.off");
            cir.setReturnValue(true);
            cir.cancel();
        }
    }
}