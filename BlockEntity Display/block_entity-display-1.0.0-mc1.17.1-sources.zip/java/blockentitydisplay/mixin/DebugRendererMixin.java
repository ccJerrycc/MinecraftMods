package blockentitydisplay.mixin;

import blockentitydisplay.Client;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.debug.DebugRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashSet;
import java.util.Set;

@Mixin(DebugRenderer.class)
public abstract class DebugRendererMixin {
    @Inject(at = @At("TAIL"), method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;DDD)V")
    private void Irender(MatrixStack matrices, VertexConsumerProvider.Immediate vertexConsumers, double cameraX, double cameraY, double cameraZ, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (Client.showBlockEntity && !client.hasReducedDebugInfo()) {
            RenderSystem.setShader(GameRenderer::getPositionShader);
            RenderSystem.setShaderColor(0, 1, 0, 0.25f);
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableCull();
            RenderSystem.disableTexture();

            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder buffer = tessellator.getBuffer();

            int viewDist = client.options.viewDistance >> 1;
            ClientWorld world = client.world;
            Entity entity = client.gameRenderer.getCamera().getFocusedEntity();
            BlockPos blockPos = entity.getBlockPos();
            int chunkX = blockPos.getX() >> 4;
            int chunkY = blockPos.getY() >> 4;
            int chunkZ = blockPos.getZ() >> 4;
            int minY = (chunkY - viewDist) << 4;
            int maxY = (chunkY + viewDist + 1) << 4;

            Set<BlockPos> blockEntities = new HashSet<>();
            for (int chunkI = -viewDist; chunkI <= viewDist; ++chunkI)
                for (int chunkK = -viewDist; chunkK <= viewDist; ++chunkK)
                    for (BlockPos iblockPos : world.getChunk(chunkX + chunkI, chunkZ + chunkK).getBlockEntityPositions())
                        if (minY <= iblockPos.getY() && iblockPos.getY() < maxY)
                            blockEntities.add(iblockPos);

            buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION);
            for (BlockPos iblockPos : blockEntities) {
                double x1 = iblockPos.getX() - cameraX;
                double y1 = iblockPos.getY() - cameraY;
                double z1 = iblockPos.getZ() - cameraZ;
                double x2 = x1 + 1;
                double y2 = y1 + 1;
                double z2 = z1 + 1;
                if (!blockEntities.contains(iblockPos.down())) {
                    buffer.vertex(x1, y1, z1).next();
                    buffer.vertex(x2, y1, z1).next();
                    buffer.vertex(x2, y1, z2).next();
                    buffer.vertex(x1, y1, z2).next();
                }
                if (!blockEntities.contains(iblockPos.up())) {
                    buffer.vertex(x2, y2, z2).next();
                    buffer.vertex(x2, y2, z1).next();
                    buffer.vertex(x1, y2, z1).next();
                    buffer.vertex(x1, y2, z2).next();
                }
                if (!blockEntities.contains(iblockPos.north())) {
                    buffer.vertex(x1, y1, z1).next();
                    buffer.vertex(x1, y2, z1).next();
                    buffer.vertex(x2, y2, z1).next();
                    buffer.vertex(x2, y1, z1).next();
                }
                if (!blockEntities.contains(iblockPos.south())) {
                    buffer.vertex(x2, y2, z2).next();
                    buffer.vertex(x1, y2, z2).next();
                    buffer.vertex(x1, y1, z2).next();
                    buffer.vertex(x2, y1, z2).next();
                }
                if (!blockEntities.contains(iblockPos.west())) {
                    buffer.vertex(x1, y1, z1).next();
                    buffer.vertex(x1, y1, z2).next();
                    buffer.vertex(x1, y2, z2).next();
                    buffer.vertex(x1, y2, z1).next();
                }
                if (!blockEntities.contains(iblockPos.east())) {
                    buffer.vertex(x2, y2, z2).next();
                    buffer.vertex(x2, y1, z2).next();
                    buffer.vertex(x2, y1, z1).next();
                    buffer.vertex(x2, y2, z1).next();
                }
            }
            tessellator.draw();
        }
    }
}