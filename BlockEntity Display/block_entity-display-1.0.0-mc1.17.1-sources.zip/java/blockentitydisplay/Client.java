package blockentitydisplay;

import net.fabricmc.api.ClientModInitializer;

public class Client implements ClientModInitializer {
    public static boolean showBlockEntity;

    @Override
    public void onInitializeClient() {}
}