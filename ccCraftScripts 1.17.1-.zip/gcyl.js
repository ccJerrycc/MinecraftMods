//Type ``/cs gcyl <pattern> <radiusX> <radiusZ> [radiusY] [-h]'' to generate a cylinder
//Default is y
//-h is optional for hollowing

var local = context.getSession();
var world = player.getWorld();
var pattern = context.getBlockPattern(argv[1]);
var rX = Number(argv[2]);
var rZ = Number(argv[3]);
var dPos = player.getLocation();
if (argv[4]) {
  var rY = Number(argv[4]);
} else {
  var rY = rX;
}

var edit = local.createEditSession(player);
var negX = 0 - Math.floor(rX);
var negY = 0 - Math.floor(rY);
var negZ = 0 - Math.floor(rZ);
var center = local.getPlacementPosition(player);
var minY = world.getMinY();
var maxY = world.getMaxY();

edit.disableBuffering();
if (argv[5] == "-h") {
  if (isY(dPos.getPitch())) {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);
      let outX2 = Math.pow((i + Math.sign(i)) / rX, 2);

      for (let j = negY; j <= rY; j++) {
        let scaY2 = Math.pow(j / rY, 2);

        if (inSel(scaX2, scaY2) && onSel(outX2, scaY2, scaX2, Math.pow((j + Math.sign(j)) / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            trySet(center.add(j, k, i));
          }
        }
      }
    }
  } else if (isZ(dPos.getYaw())) {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);
      let outX2 = Math.pow((i + Math.sign(i)) / rX, 2);

      for (let j = negY; j <= rY; j++) {
        let scaY2 = Math.pow(j / rY, 2);

        if (inSel(scaX2, scaY2) && onSel(outX2, scaY2, scaX2, Math.pow((j + Math.sign(j)) / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            trySet(center.add(i, j, k));
          }
        }
      }
    }
  } else {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);
      let outX2 = Math.pow((i + Math.sign(i)) / rX, 2);

      for (let j = negY; j <= rY; j++) {
        let scaY2 = Math.pow(j / rY, 2);

        if (inSel(scaX2, scaY2) && onSel(outX2, scaY2, scaX2, Math.pow((j + Math.sign(j)) / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            trySet(center.add(k, i, j));
          }
        }
      }
    }
  }
} else {
  if (isY(dPos.getPitch())) {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);

      for (let j = negY; j <= rY; j++) {
        if (inSel(scaX2, Math.pow(j / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            trySet(center.add(j, k, i));
          }
        }
      }
    }
  } else if (isZ(dPos.getYaw())) {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);

      for (let j = negY; j <= rY; j++) {
        if (inSel(scaX2, Math.pow(j / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            trySet(center.add(i, j, k));
          }
        }
      }
    }
  } else {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);

      for (let j = negY; j <= rY; j++) {
        if (inSel(scaX2, Math.pow(j / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            trySet(center.add(k, i, j));
          }
        }
      }
    }
  }
}
local.remember(edit);
player.print("Cylinder has been generated");

function isY(ppitch) {
  return ppitch <= -45 || 45 <= ppitch;
}
function isZ(pyaw) {
  return pyaw < -135 || 135 < pyaw || (-45 < pyaw && pyaw < 45);
}
function inSel(pscaX2, pscaY2) {
  return pscaX2 + pscaY2 <= 1;
}
function onSel(poutX2, pscaY2, pscaX2, poutY2) {
  return poutX2 + pscaY2 > 1 || pscaX2 + poutY2 > 1;
}
function trySet(ppos) {
  var y = ppos.getY();

  if (minY <= y && y <= maxY) {
    edit.setBlock(ppos, pattern);
  }
}