//This brush can fill within spherical region
//Thanks inHaze Terraforming Toolkit for Brush
//Type ``/cs brf <pattern> <radius> <checkBlock> <minFaces>'' for binding your brushtool

importPackage(Packages.com.sk89q.worldedit.command.tool.brush); //Brush
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide
importPackage(Packages.com.sk89q.worldedit.world.block); //BlockType

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var rSel = Number(argv[2]);
var faces = [BlockVector3.at(-1, 0, 0), BlockVector3.at(0, -1, 0), BlockVector3.at(0, 0, -1), BlockVector3.at(0, 0, 1), BlockVector3.at(0, 1, 0), BlockVector3.at(1, 0, 0)];
var checkBlock = new BlockType(argv[3]);
var minFaces = Number(argv[4]);

var negSel = 0 - Math.floor(rSel);
var rSel2 = rSel * rSel;

var sel = [];
for (let i = negSel; i <= rSel; i++) {
  let i2 = i * i;

  for (let j = negSel; j <= rSel; j++) {
    let j2 = j * j;

    for (let k = negSel; k <= rSel; k++) {
      if (i2 + j2 + k * k <= rSel2) {
        sel.push(BlockVector3.at(i, j, k));
      }
    }
  }
}

var brushtool = context.getSession().getBrushTool(item);
var fill = new Brush {
  build(pedit, ppos, ppattern, psize) {
    let world = pedit.getWorld();

    let minY = world.getMinY();
    let maxY = world.getMaxY();

    let region = [];
    for (let pos of sel) {
      pos = ppos.add(pos);

      if (inHeight(pos.getY()) && isFill(pos)) {
        region.push(pos);
      }
    }

    for (let pos of region) {
      pedit.setBlock(pos, ppattern);
    }


    function inHeight(py) {
      return minY <= py && py <= maxY;
    }
    function isFill(p2pos) {
      var faceNum = 0;

      for (let face of faces) {
        faceNum += checkBlock.equals(pedit.getBlock(p2pos.add(face)).getBlockType());
        if (minFaces <= faceNum) {
          return true;
        }
      }

      return false;
    }
  }
}

brushtool.setBrush(fill, "");
brushtool.setFill(context.getBlockPattern(argv[1]));
player.print("Fill Brush bound to " + item.getName());