//This brush can set a diamond
//Type ``/cs brd <pattern> <radiusX> [radiusY] [radiusZ] [-h]'' for binding your brushtool
//-h is optional for hollowing

importPackage(Packages.com.sk89q.worldedit.command.tool.brush); //Brush
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var rX = Number(argv[2]);
if (argv[3]) {
  var rY = Number(argv[3]);
  var rZ = Number(argv[4]);
} else {
  var rY = rX;
  var rZ = rX;
}

var negX = 0 - Math.floor(rX);
var negY = 0 - Math.floor(rY);
var negZ = 0 - Math.floor(rZ);

var sel = [];
if (argv[5] == "-h") {
  for (let i = negX; i <= rX; i++) {
    let iAbs = Math.abs(i);

    let scaX = iAbs / rX;
    let outX = (iAbs + 1) / rX;

    for (let j = negY; j <= rY; j++) {
      let jAbs = Math.abs(j);

      let scaY = jAbs / rY;
      let outY = (jAbs + 1) / rY;

      for (let k = negZ; k <= rZ; k++) {
        let kAbs = Math.abs(k);

        let scaZ = kAbs / rZ;

        if (inSel(scaX, scaY, scaZ) && (onSel(outX, scaY, scaZ) || onSel(scaX, outY, scaZ) || onSel(scaX, scaY, (kAbs + 1) / rZ))) {
          sel.push(BlockVector3.at(i, j, k));
        }
      }
    }
  }
} else {
  for (let i = negX; i <= rX; i++) {
    let scaX = Math.abs(i) / rX;

    for (let j = negY; j <= rY; j++) {
      let scaY = Math.abs(j) / rY;

      for (let k = negZ; k <= rZ; k++) {
        if (inSel(scaX, scaY, Math.abs(k) / rZ)) {
          sel.push(BlockVector3.at(i, j, k));
        }
      }
    }
  }
}

var brushtool = context.getSession().getBrushTool(item);
var diamond = new Brush {
  build(pedit, ppos, ppattern, psize) {
    let world = pedit.getWorld();

    let minY = world.getMinY();
    let maxY = world.getMaxY();

    for (let pos of sel) {
      pos = ppos.add(pos);

      if (inHeight(pos.getY())) {
        pedit.setBlock(pos, ppattern);
      }
    }

    function inHeight(py) {
      return minY <= py && py <= maxY;
    }
  }
}

brushtool.setBrush(diamond, "");
brushtool.setFill(context.getBlockPattern(argv[1]));
player.print("Diamond Brush bound to " + item.getName());

function inSel(pscaX, pscaY, pscaZ) {
  return pscaX + pscaY + pscaZ <= 1;
}
function onSel(px, py, pz) {
  return px + py + pz > 1;
}