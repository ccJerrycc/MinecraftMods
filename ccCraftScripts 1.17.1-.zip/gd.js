//Type ``/cs gd <pattern> <radiusX> [radiusY] [radiusZ] [-h]'' to generate a diamond
//-h is optional for hollowing

var local = context.getSession();
var world = player.getWorld();
var pattern = context.getBlockPattern(argv[1]);
var rX = Number(argv[2]);
if (argv[3]) {
  var rY = Number(argv[3]);
  var rZ = Number(argv[4]);
} else {
  var rY = rX;
  var rZ = rX;
}

var edit = local.createEditSession(player);
var negX = 0 - Math.floor(rX);
var negY = 0 - Math.floor(rY);
var negZ = 0 - Math.floor(rZ);
var center = local.getPlacementPosition(player);
var minY = world.getMinY();
var maxY = world.getMaxY();

edit.disableBuffering();
if (argv[5] == "-h") {
  for (let i = negX; i <= rX; i++) {
    let iAbs = Math.abs(i);

    let scaX = iAbs / rX;
    let outX = (iAbs + 1) / rX;

    for (let j = negY; j <= rY; j++) {
      let jAbs = Math.abs(j);

      let scaY = jAbs / rY;
      let outY = (jAbs + 1) / rY;

      for (let k = negZ; k <= rZ; k++) {
        let kAbs = Math.abs(k);

        let scaZ = kAbs / rZ;

        if (inSel(scaX, scaY, scaZ) && (onSel(outX, scaY, scaZ) || onSel(scaX, outY, scaZ) || onSel(scaX, scaY, (kAbs + 1) / rZ))) {
          trySet(center.add(i, j, k));
        }
      }
    }
  }
} else {
  for (let i = negX; i <= rX; i++) {
    let scaX = Math.abs(i) / rX;

    for (let j = negY; j <= rY; j++) {
      let scaY = Math.abs(j) / rY;

      for (let k = negZ; k <= rZ; k++) {
        if (inSel(scaX, scaY, Math.abs(k) / rZ)) {
          trySet(center.add(i, j, k));
        }
      }
    }
  }
}
local.remember(edit);
player.print("Diamond has been generated");

function inSel(pscaX, pscaY, pscaZ) {
  return pscaX + pscaY + pscaZ <= 1;
}
function onSel(px, py, pz) {
  return px + py + pz > 1;
}
function trySet(ppos) {
  var y = ppos.getY();

  if (minY <= y && y <= maxY) {
    edit.setBlock(ppos, pattern);
  }
}