//This tool can set a convex-polyhedron by left-clicking vertices then right-clicking
//Type ``/cs tcp <pattern> [-h]'' for binding your tool
//-h is optional for hollowing

importPackage(Packages.com.sk89q.worldedit.command.tool); //DoubleActionTraceTool
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var pattern = context.getBlockPattern(argv[1]);
var sel = [];

if (argv[2] == "-h") {
  var convex = new DoubleActionTraceTool {
    actSecondary(pserver, pconfig, pplayer, plocal) {
      let edit = plocal.createEditSession(pplayer);
      let dPos = pplayer.getLocation();

      let direction = dPos.getDirection().divide(16);
      let vertex = dPos.toVector().add(0, 1.62, 0);
      for (let i = 0.0625; i <= 1024; i += 0.0625) {
        vertex = vertex.add(direction);
        if (isnAir(vertex.toBlockPoint())) {
          if (hasn(sel, vertex)) {
            let lines = [];
            for (let pos of sel) {
              let dv = pos.subtract(vertex);

              let dx = dv.getX();
              let dy = dv.getY();
              let dz = dv.getZ();

              let dydx = dy / dx;
              let dzdx = dz / dx;
              let dxdy = dx / dy;
              let dzdy = dz / dy;
              let dxdz = dx / dz;
              let dydz = dy / dz;
              let signX = Math.sign(dx);
              let signY = Math.sign(dy);
              let signZ = Math.sign(dz);

              let supX = dx + signX;
              let supY = dy + signY;
              let supZ = dz + signZ;
              let halfX = signX / 2;
              let halfY = signY / 2;
              let halfZ = signZ / 2;

              for (let i = signX; i != supX; i += signX) {
                if (tryAdd(lines, vertex.add(i, Math.round((i - halfX) * dydx), Math.round((i - halfX) * dzdx)))) {
                  break;
                }
              }
              for (let j = signY; j != supY; j += signY) {
                if (tryAdd(lines, vertex.add(Math.round((j - halfY) * dxdy), j, Math.round((j - halfY) * dzdy)))) {
                  break;
                }
              }
              for (let k = signZ; k != supZ; k += signZ) {
                if (tryAdd(lines, vertex.add(Math.round((k - halfZ) * dxdz), Math.round((k - halfZ) * dydz), k))) {
                  break;
                }
              }
            }

            for (let pos of lines) {
              sel.push(pos);
            }
            sel.push(vertex);
            pplayer.print("hConvex-Polyhedron: " + vertex + " , ...");
          }
          break;
        }
      }

      return true;

      function isnAir(ppos) {
        if (edit.getBlock(ppos).getBlockType().getId() != "minecraft:air") {
          vertex = ppos;

          return true;
        }
      }
    }, actPrimary(pserver, pconfig, pplayer, plocal) {
      let boundary = [];
      for (let pos of sel) {
        if (hasn(sel, pos.add(1, 0, 0)) || hasn(sel, pos.add(0, 1, 0)) || hasn(sel, pos.add(0, 0, 1)) || hasn(sel, pos.subtract(1, 0, 0)) || hasn(sel, pos.subtract(0, 1, 0)) || hasn(sel, pos.subtract(0, 0, 1))) {
          boundary.push(pos);
        }
      }

      let edit = plocal.createEditSession(pplayer);
      let world = pplayer.getWorld();

      let minY = world.getMinY();
      let maxY = world.getMaxY();

      edit.disableBuffering();
      for (let pos of boundary) {
        if (inHeight(pos.getY())) {
          edit.setBlock(pos, pattern);
        }
      }
      plocal.remember(edit);
      pplayer.print("hConvex-Polyhedron has been set");
      sel = [];

      return true;

      function inHeight(py) {
        return minY <= py && py <= maxY;
      }
    }, canUse(pplayer) {
      return true;
    }
  }
} else {
  var convex = new DoubleActionTraceTool {
    actSecondary(pserver, pconfig, pplayer, plocal) {
      let edit = plocal.createEditSession(pplayer);
      let dPos = pplayer.getLocation();

      let direction = dPos.getDirection().divide(16);
      let vertex = dPos.toVector().add(0, 1.62, 0);
      for (let i = 0.0625; i <= 1024; i += 0.0625) {
        vertex = vertex.add(direction);
        if (isnAir(vertex.toBlockPoint())) {
          if (hasn(sel, vertex)) {
            let lines = [];
            for (let pos of sel) {
              let dv = pos.subtract(vertex);

              let dx = dv.getX();
              let dy = dv.getY();
              let dz = dv.getZ();

              let dydx = dy / dx;
              let dzdx = dz / dx;
              let dxdy = dx / dy;
              let dzdy = dz / dy;
              let dxdz = dx / dz;
              let dydz = dy / dz;
              let signX = Math.sign(dx);
              let signY = Math.sign(dy);
              let signZ = Math.sign(dz);

              let supX = dx + signX;
              let supY = dy + signY;
              let supZ = dz + signZ;
              let halfX = signX / 2;
              let halfY = signY / 2;
              let halfZ = signZ / 2;

              for (let i = signX; i != supX; i += signX) {
                if (tryAdd(lines, vertex.add(i, Math.round((i - halfX) * dydx), Math.round((i - halfX) * dzdx)))) {
                  break;
                }
              }
              for (let j = signY; j != supY; j += signY) {
                if (tryAdd(lines, vertex.add(Math.round((j - halfY) * dxdy), j, Math.round((j - halfY) * dzdy)))) {
                  break;
                }
              }
              for (let k = signZ; k != supZ; k += signZ) {
                if (tryAdd(lines, vertex.add(Math.round((k - halfZ) * dxdz), Math.round((k - halfZ) * dydz), k))) {
                  break;
                }
              }
            }

            for (let pos of lines) {
              sel.push(pos);
            }
            sel.push(vertex);
            pplayer.print("Convex-Polyhedron: " + vertex + " , ...");
          }
          break;
        }
      }

      return true;

      function isnAir(ppos) {
        if (edit.getBlock(ppos).getBlockType().getId() != "minecraft:air") {
          vertex = ppos;

          return true;
        }
      }
    }, actPrimary(pserver, pconfig, pplayer, plocal) {
      let edit = plocal.createEditSession(pplayer);
      let world = pplayer.getWorld();

      let minY = world.getMinY();
      let maxY = world.getMaxY();

      edit.disableBuffering();
      for (let pos of sel) {
        if (inHeight(pos.getY())) {
          edit.setBlock(pos, pattern);
        }
      }
      plocal.remember(edit);
      pplayer.print("Convex-Polyhedron has been set");
      sel = [];

      return true;

      function inHeight(py) {
        return minY <= py && py <= maxY;
      }
    }, canUse(pplayer) {
      return true;
    }
  }
}

context.getSession().setTool(item, convex);
player.print("Convex-Polyhedron Tool bound to " + item.getName());

function hasn(psel, pvertex) {
  for (let ppos of psel) {
    if (pvertex.equals(ppos)) {
      return false;
    }
  }

  return true;
}

function tryAdd(plines, ppos) {
  if (hasn(plines, ppos)) {
    if (hasn(sel, ppos)) {
      plines.push(ppos);
    } else {
      return false;
    }
  }

  return false;
}