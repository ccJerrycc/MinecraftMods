//This brush can set a cylinder
//Type ``/cs brcyl <pattern> <radiusX> <sizeZ> [x/y/z] [radiusY] [-h]'' for binding your brushtool
//Default is y
//-h is optional for hollowing

importPackage(Packages.com.sk89q.worldedit.command.tool.brush); //Brush
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var rX = Number(argv[2]);
var rZ = Number(argv[3]);
if (argv[4]) {
  var axis = argv[4];
  var rY = Number(argv[5]);
} else {
  var axis = "y";
  var rY = rX;
}

var negX = 0 - Math.floor(rX);
var negY = 0 - Math.floor(rY);
var negZ = 0 - Math.floor(rZ);

var sel = [];
if (argv[6] == "-h") {
  if (axis == "y") {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);
      let outX2 = Math.pow((i + Math.sign(i)) / rX, 2);

      for (let j = negY; j <= rY; j++) {
        let scaY2 = Math.pow(j / rY, 2);

        if (inSel(scaX2, scaY2) && onSel(outX2, scaY2, scaX2, Math.pow((j + Math.sign(j)) / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            sel.push(BlockVector3.at(j, k, i));
          }
        }
      }
    }
  } else if (axis == "z") {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);
      let outX2 = Math.pow((i + Math.sign(i)) / rX, 2);

      for (let j = negY; j <= rY; j++) {
        let scaY2 = Math.pow(j / rY, 2);

        if (inSel(scaX2, scaY2) && onSel(outX2, scaY2, scaX2, Math.pow((j + Math.sign(j)) / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            sel.push(BlockVector3.at(i, j, k));
          }
        }
      }
    }
  } else if (axis == "x") {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);
      let outX2 = Math.pow((i + Math.sign(i)) / rX, 2);

      for (let j = negY; j <= rY; j++) {
        let scaY2 = Math.pow(j / rY, 2);

        if (inSel(scaX2, scaY2) && onSel(outX2, scaY2, scaX2, Math.pow((j + Math.sign(j)) / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            sel.push(BlockVector3.at(k, i, j));
          }
        }
      }
    }
  }
} else {
  if (axis == "y") {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);

      for (let j = negY; j <= rY; j++) {
        if (inSel(scaX2, Math.pow(j / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            sel.push(BlockVector3.at(j, k, i));
          }
        }
      }
    }
  } else if (axis == "z") {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);

      for (let j = negY; j <= rY; j++) {
        if (inSel(scaX2, Math.pow(j / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            sel.push(BlockVector3.at(i, j, k));
          }
        }
      }
    }
  } else if (axis == "x") {
    for (let i = negX; i <= rX; i++) {
      let scaX2 = Math.pow(i / rX, 2);

      for (let j = negY; j <= rY; j++) {
        if (inSel(scaX2, Math.pow(j / rY, 2))) {
          for (let k = negZ; k <= rZ; k++) {
            sel.push(BlockVector3.at(k, i, j));
          }
        }
      }
    }
  }
}

var brushtool = context.getSession().getBrushTool(item);
var cylinder = new Brush {
  build(pedit, ppos, ppattern, psize) {
    let world = pedit.getWorld();

    let minY = world.getMinY();
    let maxY = world.getMaxY();

    for (let pos of sel) {
      pos = ppos.add(pos);

      if (inHeight(pos.getY())) {
        pedit.setBlock(pos, ppattern);
      }
    }

    function inHeight(py) {
      return (minY <= py && py <= maxY);
    }
  }
}

brushtool.setBrush(cylinder, "");
brushtool.setFill(context.getBlockPattern(argv[1]));
player.print("Cylinder Brush bound to " + item.getName());

function inSel(pscaX2, pscaY2) {
  return pscaX2 + pscaY2 <= 1;
}
function onSel(poutX2, pscaY2, pscaX2, poutY2) {
  return poutX2 + pscaY2 > 1 || pscaX2 + poutY2 > 1;
}