//Type ``/cs gc <pattern> <radiusX> [radiusY] [radiusZ] [-h]'' to generate a cube
//-h is optional for hollowing

var local = context.getSession();
var world = player.getWorld();
var pattern = context.getBlockPattern(argv[1]);
var rX = Number(argv[2]);
if (argv[3]) {
  var rY = Number(argv[3]);
  var rZ = Number(argv[4]);
} else {
  var rY = rX;
  var rZ = rX;
}

var edit = local.createEditSession(player);
var negX = 0 - rX;
var negY = 0 - rY;
var negZ = 0 - rZ;
var center = local.getPlacementPosition(player);
var minY = world.getMinY();
var maxY = world.getMaxY();

edit.disableBuffering();
if (argv[5] == "-h") {
  for (let i = negX; i <= rX; i++) {
    for (let j = negY; j <= rY; j++) {
      trySet(center.add(i, j, negZ));
      trySet(center.add(i, j, rZ));
    }
  }
  for (let i = negX; i <= rX; i++) {
    for (let k = negZ + 1; k < rZ; k++) {
      trySet(center.add(i, negY, k));
      trySet(center.add(i, rY, k));
    }
  }
  for (let j = negY + 1; j < rY; j++) {
    for (let k = negZ + 1; k < rZ; k++) {
      trySet(center.add(negX, j, k));
      trySet(center.add(rX, j, k));
    }
  }
} else {
  for (let i = negX; i <= rX; i++) {
    for (let j =negY; j <= rY; j++) {
      for (let k = negZ; k <= rZ; k++) {
        trySet(center.add(i, j, k));
      }
    }
  }
}
local.remember(edit);
player.print("Cube has been generated");

function trySet(ppos) {
  var y = ppos.getY();

  if (minY <= y && y <= maxY) {
    edit.setBlock(ppos, pattern);
  }
}