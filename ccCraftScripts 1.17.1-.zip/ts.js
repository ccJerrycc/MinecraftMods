//This tool can set a sphere by left-clicking pos1 and pos2 then right-clicking
//Type ``/cs ts <pattern> [-h]'' for binding your tool
//-h is optional for hollowing

importPackage(Packages.com.sk89q.worldedit.command.tool); //DoubleActionTraceTool
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var pattern = context.getBlockPattern(argv[1]);
var pos1;
var pos2;

if (argv[2] == "-h") {
  var sphere = new DoubleActionTraceTool {
    actSecondary(pserver, pconfig, pplayer, plocal) {
      let edit = plocal.createEditSession(pplayer);
      let dPos = pplayer.getLocation();

      let direction = dPos.getDirection().divide(16);
      let pos = dPos.toVector().add(0, 1.62, 0);
      for (let i = 0.0625; i <= 1024; i += 0.0625) {
        pos = pos.add(direction);
        if (isnAir(pos.toBlockPoint())) {
          pplayer.print("hSphere: " + pos1 + " , " + pos2);
          break;
        }
      }

      return true;

      function isnAir(ppos) {
        if (edit.getBlock(ppos).getBlockType().getId() != "minecraft:air") {
          pos2 = pos1;
          pos1 = ppos;

          return true;
        }
      }
    }, actPrimary(pserver, pconfig, pplayer, plocal) {
      if (!pos1 || !pos2) {
        pplayer.print("hSphere: " + pos1 + " , " + pos2);

        return true;
      }

      let edit = plocal.createEditSession(pplayer);
      let world = pplayer.getWorld();
      let minPos = pos1.getMinimum(pos2);
      let maxPos = pos1.getMaximum(pos2);

      let rX = maxPos.getX() - minPos.getX() + 1;
      let rY = maxPos.getY() - minPos.getY() + 1;
      let rZ = maxPos.getZ() - minPos.getZ() + 1;
      let center = minPos.add(maxPos);
      let minY = world.getMinY();
      let maxY = world.getMaxY();

      let negX = 1 - rX;
      let negY = 1 - rY;
      let negZ = 1 - rZ;

      edit.disableBuffering();
      for (let i = negX; i <= rX; i += 2) {
        let scaX2 = Math.pow(i / rX, 2);
        let outX2 = Math.pow((i + dSign(i)) / rX, 2);

        for (let j = negY; j <= rY; j += 2) {
          let scaY2 = Math.pow(j / rY, 2);
          let outY2 = Math.pow((j + dSign(j)) / rY, 2);

          for (let k = negZ; k <= rZ; k += 2) {
            let scaZ2 = Math.pow(k / rZ, 2);

            if (inSel(scaX2, scaY2, scaZ2) && onSel(scaX2, scaY2, scaZ2, outX2, outY2, Math.pow((k + dSign(k)) / rZ, 2))) {
              trySet(center.add(i, j, k).divide(2));
            }
          }
        }
      }
      plocal.remember(edit);
      pplayer.print("hSphere has been set");
      pos1 = undefined;
      pos2 = undefined;

      return true;

      function trySet(ppos) {
        var y = ppos.getY();

        if (minY <= y && y <= maxY) {
          edit.setBlock(ppos, pattern);
        }
      }
    }, canUse(pplayer) {
      return true;
    }
  }
} else {
  var sphere = new DoubleActionTraceTool {
    actSecondary(pserver, pconfig, pplayer, plocal) {
      let edit = plocal.createEditSession(pplayer);
      let dPos = pplayer.getLocation();

      let direction = dPos.getDirection().divide(16);
      let pos = dPos.toVector().add(0, 1.62, 0);
      for (let i = 0.0625; i <= 1024; i += 0.0625) {
        pos = pos.add(direction);
        if (isnAir(pos.toBlockPoint())) {
          pplayer.print("Sphere: " + pos1 + " , " + pos2);
          break;
        }
      }

      return true;

      function isnAir(ppos) {
        if (edit.getBlock(ppos).getBlockType().getId() != "minecraft:air") {
          pos2 = pos1;
          pos1 = ppos;

          return true;
        }
      }
    }, actPrimary(pserver, pconfig, pplayer, plocal) {
      if (!pos1 || !pos2) {
        pplayer.print("Sphere: " + pos1 + " , " + pos2);

        return true;
      }

      let edit = plocal.createEditSession(pplayer);
      let world = pplayer.getWorld();
      let minPos = pos1.getMinimum(pos2);
      let maxPos = pos1.getMaximum(pos2);

      let rX = maxPos.getX() - minPos.getX() + 1;
      let rY = maxPos.getY() - minPos.getY() + 1;
      let rZ = maxPos.getZ() - minPos.getZ() + 1;
      let center = minPos.add(maxPos);
      let minY = world.getMinY();
      let maxY = world.getMaxY();

      let negX = 1 - rX;
      let negY = 1 - rY;
      let negZ = 1 - rZ;

      edit.disableBuffering();
      for (let i = negX; i <= rX; i += 2) {
        let scaX2 = Math.pow(i / rX, 2);

        for (let j = negY; j <= rY; j += 2) {
          let scaY2 = Math.pow(j / rY, 2);

          for (let k = negZ; k <= rZ; k += 2) {
            if (inSel(scaX2, scaY2, Math.pow(k / rZ, 2))) {
              trySet(center.add(i, j, k).divide(2));
            }
          }
        }
      }
      plocal.remember(edit);
      pplayer.print("Sphere has been set");
      pos1 = undefined;
      pos2 = undefined;

      return true;

      function trySet(ppos) {
        var y = ppos.getY();

        if (minY <= y && y <= maxY) {
          edit.setBlock(ppos, pattern);
        }
      }
    }, canUse(pplayer) {
      return true;
    }
  }
}

context.getSession().setTool(item, sphere);
player.print("Sphere Tool bound to " + item.getName());

function dSign(px) {
  if (px > 0) {
    return 2;
  }
  if (px == 0) {
    return 0;
  }
  if (px < 0) {
    return -2;
  }
}
function inSel(pscaX2, pscaY2, pscaZ2) {
  return pscaX2 + pscaY2 + pscaZ2 <= 1;
}
function onSel(pscaX2, pscaY2, pscaZ2, poutX2, poutY2, poutZ2) {
  return poutX2 + pscaY2 + pscaZ2 > 1 || pscaX2 + poutY2 + pscaZ2 > 1 || pscaX2 + pscaY2 + poutZ2 > 1;
}