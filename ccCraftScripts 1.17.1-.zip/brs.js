//This brush can set a sphere
//Thanks FastAsyncWorldEdit for Algorithm
//Type ``/cs brs <pattern> <radiusX> [radiusY] [radiusZ] [-h]'' for binding your brushtool
//-h is optional for hollowing

importPackage(Packages.com.sk89q.worldedit.command.tool.brush); //Brush
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var rX = Number(argv[2]);
if (argv[3]) {
  var rY = Number(argv[3]);
  var rZ = Number(argv[4]);
} else {
  var rY = rX;
  var rZ = rX;
}

var negX = 0 - Math.floor(rX);
var negY = 0 - Math.floor(rY);
var negZ = 0 - Math.floor(rZ);

var sel = [];
if (argv[5] == "-h") {
  for (let i = negX; i <= rX; i++) {
    let scaX2 = Math.pow(i / rX, 2);
    let outX2 = Math.pow((i + Math.sign(i)) / rX, 2);

    for (let j = negY; j <= rY; j++) {
      let scaY2 = Math.pow(j / rY, 2);
      let outY2 = Math.pow((j + Math.sign(j)) / rY, 2);

      for (let k = negZ; k <= rZ; k++) {
        let scaZ2 = Math.pow(k / rZ, 2);

        if (inSel(scaX2, scaY2, scaZ2) && onSel(scaX2, scaY2, scaZ2, outX2, outY2, Math.pow((k + Math.sign(k)) / rZ, 2))) {
          sel.push(BlockVector3.at(i, j, k));
        }
      }
    }
  }
} else {
  for (let i = negX; i <= rX; i++) {
    let scaX2 = Math.pow(i / rX, 2);

    for (let j = negY; j <= rY; j++) {
      let scaY2 = Math.pow(j / rY, 2);

      for (let k = negZ; k <= rZ; k++) {
        if (inSel(scaX2, scaY2, Math.pow(k / rZ, 2))) {
          sel.push(BlockVector3.at(i, j, k));
        }
      }
    }
  }
}

var brushtool = context.getSession().getBrushTool(item);
var sphere = new Brush {
  build(pedit, ppos, ppattern, psize) {
    let world = pedit.getWorld();

    let minY = world.getMinY();
    let maxY = world.getMaxY();

    for (let pos of sel) {
      pos = ppos.add(pos);

      if (inHeight(pos.getY())) {
        pedit.setBlock(pos, ppattern);
      }
    }

    function inHeight(py) {
      return minY <= py && py <= maxY;
    }
  }
}

brushtool.setBrush(sphere, "");
brushtool.setFill(context.getBlockPattern(argv[1]));
player.print("Sphere Brush bound to " + item.getName());

function inSel(pscaX2, pscaY2, pscaZ2) {
  return pscaX2 + pscaY2 + pscaZ2 <= 1;
}
function onSel(pscaX2, pscaY2, pscaZ2, poutX2, poutY2, poutZ2) {
  return poutX2 + pscaY2 + pscaZ2 > 1 || pscaX2 + poutY2 + pscaZ2 > 1 || pscaX2 + pscaY2 + poutZ2 > 1;
}