//This tool can set a cube by left-clicking pos1 and pos2 then right-clicking
//Type ``/cs tc <pattern> [-h]'' for binding your tool
//-h is optional for hollowing

importPackage(Packages.com.sk89q.worldedit.command.tool); //DoubleActionTraceTool
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var pattern = context.getBlockPattern(argv[1]);
var pos1;
var pos2;

if (argv[2] == "-h") {
  var cube = new DoubleActionTraceTool {
    actSecondary(pserver, pconfig, pplayer, plocal) {
      let edit = plocal.createEditSession(pplayer);
      let dPos = pplayer.getLocation();

      let direction = dPos.getDirection().divide(16);
      let pos = dPos.toVector().add(0, 1.62, 0);
      for (let i = 0.0625; i <= 1024; i += 0.0625) {
        pos = pos.add(direction);
        if (isnAir(pos.toBlockPoint())) {
          pplayer.print("hCube: " + pos1 + " , " + pos2);
          break;
        }
      }

      return true;

      function isnAir(ppos) {
        if (edit.getBlock(ppos).getBlockType().getId() != "minecraft:air") {
          pos2 = pos1;
          pos1 = ppos;

          return true;
        }
      }
    }, actPrimary(pserver, pconfig, pplayer, plocal) {
      if (!pos1 || !pos2) {
        pplayer.print("hCube: " + pos1 + " , " + pos2);

        return true;
      }

      let edit = plocal.createEditSession(pplayer);
      let world = pplayer.getWorld();
      let minPos = pos1.getMinimum(pos2);
      let maxPos = pos1.getMaximum(pos2);

      let dx = maxPos.getX() - minPos.getX();
      let dy = maxPos.getY() - minPos.getY();
      let dz = maxPos.getZ() - minPos.getZ();
      let minY = world.getMinY();
      let maxY = world.getMaxY();

      edit.disableBuffering();
      for (let i = 0; i <= dx; i++) {
        for (let j = 0; j <= dy; j++) {
          trySet(minPos.add(i, j, 0));
          trySet(minPos.add(i, j, dz));
        }
      }
      for (let i = 0; i <= dx; i++) {
        for (let k = 1; k < dz; k++) {
          trySet(minPos.add(i, 0, k));
          trySet(minPos.add(i, dy, k));
        }
      }
      for (let j = 1; j < dy; j++) {
        for (let k = 1; k < dz; k++) {
          trySet(minPos.add(0, j, k));
          trySet(minPos.add(dx, j, k));
        }
      }
      plocal.remember(edit);
      pplayer.print("hCube has been set");
      pos1 = undefined;
      pos2 = undefined;

      return true;

      function trySet(ppos) {
        var y = ppos.getY();

        if (minY <= y && y <= maxY) {
          edit.setBlock(ppos, pattern);
        }
      }
    }, canUse(pplayer) {
      return true;
    }
  }
} else {
  var cube = new DoubleActionTraceTool {
    actSecondary(pserver, pconfig, pplayer, plocal) {
      let edit = plocal.createEditSession(pplayer);
      let dPos = pplayer.getLocation();

      let direction = dPos.getDirection().divide(16);
      let pos = dPos.toVector().add(0, 1.62, 0);
      for (let i = 0.0625; i <= 1024; i += 0.0625) {
        pos = pos.add(direction);
        if (isnAir(pos.toBlockPoint())) {
          pplayer.print("Cube: " + pos1 + " , " + pos2);
          break;
        }
      }

      return true;

      function isnAir(ppos) {
        if (edit.getBlock(ppos).getBlockType().getId() != "minecraft:air") {
          pos2 = pos1;
          pos1 = ppos;

          return true;
        }
      }
    }, actPrimary(pserver, pconfig, pplayer, plocal) {
      if (!pos1 || !pos2) {
        pplayer.print("Cube: " + pos1 + " , " + pos2);

        return true;
      }

      let edit = plocal.createEditSession(pplayer);
      let world = pplayer.getWorld();
      let minPos = pos1.getMinimum(pos2);
      let maxPos = pos1.getMaximum(pos2);

      let dx = maxPos.getX() - minPos.getX();
      let dy = maxPos.getY() - minPos.getY();
      let dz = maxPos.getZ() - minPos.getZ();
      let minY = world.getMinY();
      let maxY = world.getMaxY();

      edit.disableBuffering();
      for (let i = 0; i <= dx; i++) {
        for (let j = 0; j <= dy; j++) {
          for (let k = 0; k <= dz; k++) {
            trySet(minPos.add(i, j, k));
          }
        }
      }
      plocal.remember(edit);
      pplayer.print("Cube has been set");
      pos1 = undefined;
      pos2 = undefined;

      return true;

      function trySet(ppos) {
        var y = ppos.getY();

        if (minY <= y && y <= maxY) {
          edit.setBlock(ppos, pattern);
        }
      }
    }, canUse(pplayer) {
      return true;
    }
  }
}

context.getSession().setTool(item, cube);
player.print("Cube Tool bound to " + item.getName());