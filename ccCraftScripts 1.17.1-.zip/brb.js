//This brush can blend within spherical region
//感謝 JeadTW#9920 的推薦
//Thanks FastAsyncWorldEdit for Brush
//Type ``/cs brb <pattern> <radius> <checkBlock> <minSurrounds>'' for binding your brushtool

importPackage(Packages.com.sk89q.worldedit.command.tool.brush); //Brush
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide
importPackage(Packages.com.sk89q.worldedit.world.block); //BlockType

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var rSel = Number(argv[2]);
var surs = [BlockVector3.at(-1, -1, -1), BlockVector3.at(-1, -1, 0), BlockVector3.at(-1, -1, 1), BlockVector3.at(-1, 0, -1), BlockVector3.at(-1, 0, 0), BlockVector3.at(-1, 0, 1), BlockVector3.at(-1, 1, -1), BlockVector3.at(-1, 1, 0), BlockVector3.at(-1, 1, 1), BlockVector3.at(0, -1, -1), BlockVector3.at(0, -1, 0), BlockVector3.at(0, -1, 1), BlockVector3.at(0, 0, -1), BlockVector3.at(0, 0, 1), BlockVector3.at(0, 1, -1), BlockVector3.at(0, 1, 0), BlockVector3.at(0, 1, 1), BlockVector3.at(1, -1, -1), BlockVector3.at(1, -1, 0), BlockVector3.at(1, -1, 1), BlockVector3.at(1, 0, -1), BlockVector3.at(1, 0, 0), BlockVector3.at(1, 0, 1), BlockVector3.at(1, 1, -1), BlockVector3.at(1, 1, 0), BlockVector3.at(1, 1, 1)];
var checkBlock = new BlockType(argv[3]);
var minSurs = Number(argv[4]);

var negSel = 0 - Math.floor(rSel);
var rSel2 = rSel * rSel;

var sel = [];
for (let i = negSel; i <= rSel; i++) {
  let i2 = i * i;

  for (let j = negSel; j <= rSel; j++) {
    let j2 = j * j;

    for (let k = negSel; k <= rSel; k++) {
      if (i2 + j2 + k * k <= rSel2) {
        sel.push(BlockVector3.at(i, j, k));
      }
    }
  }
}

var brushtool = context.getSession().getBrushTool(item);
var blend = new Brush {
  build(pedit, ppos, ppattern, psize) {
    let world = pedit.getWorld();

    let minY = world.getMinY();
    let maxY = world.getMaxY();

    let region = [];
    for (let pos of sel) {
      pos = ppos.add(pos);

      if (inHeight(pos.getY()) && isBlend(pos)) {
        region.push(pos);
      }
    }

    for (let pos of region) {
      pedit.setBlock(pos, ppattern);
    }

    function inHeight(py) {
      return minY <= py && py <= maxY;
    }
    function isBlend(p2pos) {
      var surNum = 0;

      for (let sur of surs) {
        surNum += checkBlock.equals(pedit.getBlock(p2pos.add(sur)).getBlockType());
        if (minSurs <= surNum) {
          return true;
        }
      }

      return false;
    }
  }
}

brushtool.setBrush(blend, "");
brushtool.setFill(context.getBlockPattern(argv[1]));
player.print("Blend Brush bound to " + item.getName());