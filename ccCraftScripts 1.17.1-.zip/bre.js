//This brush can erode within spherical region
//Type ``/cs bre <pattern> <radius> <checkBlock> <minBalls>'' for binding your brushtool

importPackage(Packages.com.sk89q.worldedit.command.tool.brush); //Brush
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide
importPackage(Packages.com.sk89q.worldedit.world.block); //BlockType

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var rSel = Number(argv[2]);
var balls = [BlockVector3.at(-1, -1, 0), BlockVector3.at(-1, 0, -1), BlockVector3.at(-1, 0, 0), BlockVector3.at(-1, 0, 1), BlockVector3.at(-1, 1, 0), BlockVector3.at(0, -1, -1), BlockVector3.at(0, -1, 0), BlockVector3.at(0, -1, 1), BlockVector3.at(0, 0, -1), BlockVector3.at(0, 0, 1), BlockVector3.at(0, 1, -1), BlockVector3.at(0, 1, 0), BlockVector3.at(0, 1, 1), BlockVector3.at(1, -1, 0), BlockVector3.at(1, 0, -1), BlockVector3.at(1, 0, 0), BlockVector3.at(1, 0, 1), BlockVector3.at(1, 1, 0)];
var checkBlock = new BlockType(argv[3]);
var minBalls = Number(argv[4]);

var negSel = 0 - Math.floor(rSel);
var rSel2 = rSel * rSel;

var sel = [];
for (let i = negSel; i <= rSel; i++) {
  let i2 = i * i;

  for (let j = negSel; j <= rSel; j++) {
    let j2 = j * j;

    for (let k = negSel; k <= rSel; k++) {
      if (i2 + j2 + k * k <= rSel2) {
        sel.push(BlockVector3.at(i, j, k));
      }
    }
  }
}

var brushtool = context.getSession().getBrushTool(item);
var erode = new Brush {
  build(pedit, ppos, ppattern, psize) {
    let world = pedit.getWorld();

    let minY = world.getMinY();
    let maxY = world.getMaxY();

    let region = [];
    for (let pos of sel) {
      pos = ppos.add(pos);

      if (inHeight(pos.getY()) && isFill(pos)) {
        region.push(pos);
      }
    }

    for (let pos of region) {
      pedit.setBlock(pos, ppattern);
    }


    function inHeight(py) {
      return minY <= py && py <= maxY;
    }
    function isFill(p2pos) {
      var ballNum = 0;

      for (let ball of balls) {
        ballNum += checkBlock.equals(pedit.getBlock(p2pos.add(ball)).getBlockType());
        if (minBalls <=ballNum) {
          return true;
        }
      }

      return false;
    }
  }
}

brushtool.setBrush(erode, "");
brushtool.setFill(context.getBlockPattern(argv[1]));
player.print("Erode Brush bound to " + item.getName());