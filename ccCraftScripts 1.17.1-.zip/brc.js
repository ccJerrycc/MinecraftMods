//This brush can set a cube
//Type ``/cs brc <pattern> <radiusX> [radiusY] [radiusZ] [-h]'' for binding your brushtool
//-h is optional for hollowing

importPackage(Packages.com.sk89q.worldedit.command.tool.brush); //Brush
importPackage(Packages.com.sk89q.worldedit.math); //BlockVector3
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var rX = Number(argv[2]);
if (argv[3]) {
  var rY = Number(argv[3]);
  var rZ = Number(argv[4]);
} else {
  var rY = rX;
  var rZ = rX;
}

var negX = 0 - rX;
var negY = 0 - rY;
var negZ = 0 - rZ;

var sel = [];
if (argv[5] == "-h") {
  for (let i = negX; i <= rX; i++) {
    for (let j = negY; j <= rY; j++) {
      sel.push(BlockVector3.at(i, j, negZ));
      sel.push(BlockVector3.at(i, j, rZ));
    }
  }
  for (let i = negX; i <= rX; i++) {
    for (let k = negZ + 1; k < rZ; k++) {
      sel.push(BlockVector3.at(i, negY, k));
      sel.push(BlockVector3.at(i, rY, k));
    }
  }
  for (let j = negY + 1; j < rY; j++) {
    for (let k = negZ + 1; k < rZ; k++) {
      sel.push(BlockVector3.at(negX, j, k));
      sel.push(BlockVector3.at(rX, j, k));
    }
  }
} else {
  for (let i = negX; i <= rX; i++) {
    for (let j = negY; j <= rY; j++) {
      for (let k = negZ; k <= rZ; k++) {
        sel.push(BlockVector3.at(i, j, k));
      }
    }
  }
}

var brushtool = context.getSession().getBrushTool(item);
var cube = new Brush {
  build(pedit, ppos, ppattern, psize) {
    let world = pedit.getWorld();

    let minY = world.getMinY();
    let maxY = world.getMaxY();

    for (let pos of sel) {
      pos = ppos.add(pos);

      if (inHeight(pos.getY())) {
        pedit.setBlock(pos, ppattern);
      }
    }

    function inHeight(py) {
      return minY <= py && py <= maxY;
    }
  }
}

brushtool.setBrush(cube, "");
brushtool.setFill(context.getBlockPattern(argv[1]));
player.print("Cube Brush bound to " + item.getName());