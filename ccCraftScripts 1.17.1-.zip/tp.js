//This tool can place a block by right-clicking
//Type ``/cs tp <pattern>'' for binding your tool

importPackage(Packages.com.sk89q.worldedit.command.tool); //TraceTool
importPackage(Packages.com.sk89q.worldedit.util); //HandSide

var item = player.getItemInHand(HandSide.MAIN_HAND).getType();
var pattern = context.getBlockPattern(argv[1]);

var place = new TraceTool {
  actPrimary(pserver, pconfig, pplayer, plocal) {
    let edit = plocal.createEditSession(pplayer);
    let dPos = pplayer.getLocation();

    let direction = dPos.getDirection();
    let pos = dPos.toVector().add(0, 1.62, 0);

    let ray = pos;
    let dx = direction.getX();
    let dy = direction.getY();
    let dz = direction.getZ();

    let signX = Math.sign(dx);
    let signY = Math.sign(dy);
    let signZ = Math.sign(dz);
    let offX = getOff(dx);
    let offY = getOff(dy);
    let offZ = getOff(dz);
    let dydx = dy / dx;
    let dzdx = dz / dx;
    let dxdy = dx / dy;
    let dzdy = dz / dy;
    let dxdz = dx / dz;
    let dydz = dy / dz;

    edit.disableBuffering();
    while (true) {
      let nextX = getNext(ray.getX(), signX);
      let nextY = getNext(ray.getY(), signY);
      let nextZ = getNext(ray.getZ(), signZ);

      let lenX = nextX / dx;
      let lenY = nextY / dy;
      let lenZ = nextZ / dz;

      if (lenX <= lenY && lenX <= lenZ) {
        ray = ray.add(nextX, nextX * dydx, nextX * dzdx);
        if (tryPlace(ray.add(offX, 0, 0).toBlockPoint(), signX, 0, 0)) {
          break;
        }
      } else if (lenY <= lenZ) {
        ray = ray.add(nextY * dxdy, nextY, nextY * dzdy);
        if (tryPlace(ray.add(0, offY, 0).toBlockPoint(), 0, signY, 0)) {
          break;
        }
      } else {
        ray = ray.add(nextZ * dxdz, nextZ * dydz, nextZ);
        if (tryPlace(ray.add(0, 0, offZ).toBlockPoint(), 0, 0, signZ)) {
          break;
        }
      }
    }

    return true;

    function tryPlace(ppos, psignX, psignY, psignZ) {
      if (ray.subtract(pos).lengthSq() > 1048576) {
        pplayer.print("Out of range");

        return true;
      }
      if (edit.getBlock(ppos).getBlockType().getId() != "minecraft:air") {
        edit.setBlock(ppos.subtract(psignX, psignY, psignZ), pattern);
        plocal.remember(edit);

        return true;
      }
    }
  }, canUse(pplayer) {
    return true;
  }
}

context.getSession().setTool(item, place);
player.print("Place Tool bound to " + item.getName());

function getOff(pd) {
  if (0 <= pd) {
    return 0;
  } else {
    return -1;
  }
}
function getNext(p, psign) {
  if (0 <= psign) {
    return Math.floor(p + 1) - p;
  } else {
    return Math.ceil(p - 1) - p;
  }
}