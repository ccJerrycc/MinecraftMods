package mc47660fix.mixin;

import net.minecraft.client.particle.BlockMarkerParticle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(BlockMarkerParticle.class)
public abstract class BlockMarkerParticleMixin {
    @ModifyConstant(constant = @Constant(intValue = 80), method = "<init>(Lnet/minecraft/client/world/ClientWorld;DDDLnet/minecraft/block/BlockState;)V")
    private int MCinit(int c80) {
        return 1;
    }
}