package mc47660fix.mixin;

import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkManager;
import net.minecraft.world.dimension.Dimension;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.level.LevelProperties;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import java.util.function.BiFunction;

@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin extends World {
    protected ClientWorldMixin(LevelProperties levelProperties, DimensionType dimensionType, BiFunction<World, Dimension, ChunkManager> chunkManagerProvider, Profiler profiler, boolean isClient) {
        super(levelProperties, dimensionType, chunkManagerProvider, profiler, isClient);
    }

    @ModifyConstant(constant = @Constant(intValue = 1), method = "doRandomBlockDisplayTicks(III)V")
    private int MCdoRandomBlockDisplayTicks(int ctrue, int xCenter, int yCenter, int i) {
        BlockPos.Mutable mutable = new BlockPos.Mutable();

        for (int i2 = -32; i2 <= 32; ++i2)
            for (int j = -32; j <= 32; ++j)
                for (int k = -32; k <= 32; ++k) {
                    int x = xCenter + i2;
                    int y = yCenter + j;
                    int z = i + k;
                    
                    if (this.getBlockState(mutable.set(x, y, z)).getBlock() == Blocks.BARRIER)
                        this.addParticle(ParticleTypes.BARRIER, (double) x + 0.5, (double) y + 0.5, (double) z + 0.5, 0.0, 0.0, 0.0);
                }

        return 0;
    }
}