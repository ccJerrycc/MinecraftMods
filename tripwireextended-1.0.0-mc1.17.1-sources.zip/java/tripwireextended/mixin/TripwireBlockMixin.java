package tripwireextended.mixin;

import net.minecraft.block.TripwireBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(TripwireBlock.class)
public abstract class TripwireBlockMixin {
    @ModifyConstant(constant = @Constant(intValue = 42), method = "update(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;)V")
    private int MCupdate(int c42) {
        return 64;
    }
}