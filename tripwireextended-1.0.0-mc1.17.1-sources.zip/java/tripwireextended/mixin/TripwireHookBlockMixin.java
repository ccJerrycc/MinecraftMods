package tripwireextended.mixin;

import net.minecraft.block.TripwireHookBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(TripwireHookBlock.class)
public abstract class TripwireHookBlockMixin {
    @ModifyConstant(constant = @Constant(intValue = 42), method = "update(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;ZZILnet/minecraft/block/BlockState;)V")
    private int MCupdate(int c42) {
        return 64;
    }
}