package mc122102fix.mixin;

import net.minecraft.command.EntityDataObject;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExperienceBarUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerAbilitiesS2CPacket;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.GameMode;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

@Mixin(EntityDataObject.class)
public abstract class EntityDataObjectMixin {
    @Final
    @Shadow
    private Entity entity;

    @Inject(at = @At(
            value = "FIELD",
            target = "net/minecraft/command/EntityDataObject.INVALID_ENTITY_EXCEPTION : Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType;"
    ), cancellable = true, method = "setNbt(Lnet/minecraft/nbt/NbtCompound;)V")
    public void IsetNbt(NbtCompound nbt, CallbackInfo ci) {
        ServerPlayerEntity player = (ServerPlayerEntity) this.entity;
        NbtCompound previous = player.writeNbt(new NbtCompound());
        boolean bl = !Objects.equals(nbt.get("Pos"), previous.get("Pos"));

        if (bl) player.stopRiding();
        if (player.isSleeping()) {
            player.wakeUp(true, true);
            nbt.remove("SleepingX");
            nbt.remove("SleepingY");
            nbt.remove("SleepingZ");
            nbt.putShort("sleepTimer",(short) 0);
        }
        player.readNbt(nbt);

        if (bl || !(Objects.equals(nbt.get("Rotation"), previous.get("Rotation")))) {
            player.networkHandler.requestTeleport(player.getX(), player.getY(), player.getZ(), player.getYaw(), player.getPitch());
        }
        if (!(Objects.equals(nbt.get("Motion"), previous.get("Motion")))) {
            player.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(player));
        }
        if (!Objects.equals(nbt.get("SelectedItemSlot"), previous.get("SelectedItemSlot"))) {
            player.networkHandler.sendPacket(new UpdateSelectedSlotS2CPacket(nbt.getInt("SelectedItemSlot")));
        }
        if (!(Objects.equals(nbt.get("XpLevel"), previous.get("XpLevel")) && Objects.equals(nbt.get("XpP"), previous.get("XpP")))) {
            player.networkHandler.sendPacket(new ExperienceBarUpdateS2CPacket(player.experienceProgress, player.totalExperience, player.experienceLevel));
        }
        if (!Objects.equals(nbt.get("abilities"), previous.get("abilities"))) {
            player.networkHandler.sendPacket(new PlayerAbilitiesS2CPacket(player.getAbilities()));
        }
        if (!Objects.equals(nbt.get("playerGameType"), previous.get("playerGameType"))) {
            player.changeGameMode(GameMode.byId(nbt.getInt("playerGameType")));
        }

        ci.cancel();
    }
}