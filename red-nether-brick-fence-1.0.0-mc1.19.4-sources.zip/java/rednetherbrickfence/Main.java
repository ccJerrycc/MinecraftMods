package rednetherbrickfence;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FenceBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class Main implements ModInitializer {
    @Override
    public void onInitialize() {
        final Identifier RED_NETHER_BRICK_FENCE_ID = new Identifier("red_nether_brick_fence");
        final Block RED_NETHER_BRICK_FENCE = Registry.register(Registries.BLOCK, RED_NETHER_BRICK_FENCE_ID, new FenceBlock(AbstractBlock.Settings.copy(Blocks.RED_NETHER_BRICKS)));
        final BlockItem RED_NETHER_BRICK_FENCE_ITEM = new BlockItem(RED_NETHER_BRICK_FENCE, new Item.Settings());

        Item.BLOCK_ITEMS.put(RED_NETHER_BRICK_FENCE, RED_NETHER_BRICK_FENCE_ITEM);
        Registry.register(Registries.ITEM, RED_NETHER_BRICK_FENCE_ID, (Item) RED_NETHER_BRICK_FENCE_ITEM);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> entries.addAfter(Items.RED_NETHER_BRICK_WALL, RED_NETHER_BRICK_FENCE_ITEM));
    }
}