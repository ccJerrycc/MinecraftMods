package entitydisplay.mixin;

import entitydisplay.Client;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.debug.DebugRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DebugRenderer.class)
public abstract class DebugRendererMixin {
    @Inject(at = @At("TAIL"), method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;DDD)V")
    private void Irender(MatrixStack matrices, VertexConsumerProvider.Immediate vertexConsumers, double cameraX, double cameraY, double cameraZ, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (Client.showEntity && !client.hasReducedDebugInfo()) {
            RenderSystem.setShader(GameRenderer::getPositionShader);
            RenderSystem.setShaderColor(1, 0, 0, 0.5f);
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableCull();
            RenderSystem.disableTexture();

            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder buffer = tessellator.getBuffer();

            buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION);
            for (Entity entity : client.world.getEntities()) {
                double x1 = entity.getX() - cameraX - 0.5;
                double y1 = entity.getY() - cameraY;
                double z1 = entity.getZ() - cameraZ - 0.5;
                double x2 = x1 + 1;
                double y2 = y1 + 1;
                double z2 = z1 + 1;

                buffer.vertex(x1, y1, z1).next();
                buffer.vertex(x2, y1, z1).next();
                buffer.vertex(x2, y1, z2).next();
                buffer.vertex(x1, y1, z2).next();

                buffer.vertex(x2, y2, z2).next();
                buffer.vertex(x2, y2, z1).next();
                buffer.vertex(x1, y2, z1).next();
                buffer.vertex(x1, y2, z2).next();

                buffer.vertex(x1, y1, z1).next();
                buffer.vertex(x1, y2, z1).next();
                buffer.vertex(x2, y2, z1).next();
                buffer.vertex(x2, y1, z1).next();

                buffer.vertex(x2, y2, z2).next();
                buffer.vertex(x1, y2, z2).next();
                buffer.vertex(x1, y1, z2).next();
                buffer.vertex(x2, y1, z2).next();

                buffer.vertex(x1, y1, z1).next();
                buffer.vertex(x1, y1, z2).next();
                buffer.vertex(x1, y2, z2).next();
                buffer.vertex(x1, y2, z1).next();

                buffer.vertex(x2, y2, z2).next();
                buffer.vertex(x2, y1, z2).next();
                buffer.vertex(x2, y1, z1).next();
                buffer.vertex(x2, y2, z1).next();
            }
            tessellator.draw();
        }
    }
}