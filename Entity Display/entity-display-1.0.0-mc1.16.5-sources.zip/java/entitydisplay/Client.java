package entitydisplay;

import net.fabricmc.api.ClientModInitializer;

public class Client implements ClientModInitializer {
    public static boolean showEntity;

    @Override
    public void onInitializeClient() {}
}