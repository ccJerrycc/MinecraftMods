package biomedisplay;

import net.fabricmc.api.ClientModInitializer;

public class Client implements ClientModInitializer {
    public static boolean showBiome;
    public static int[] biomePerChunk = {0, 4, 8, 12};

    @Override
    public void onInitializeClient() {}
}