package biomedisplay.mixin;

import biomedisplay.Client;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.debug.DebugRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DebugRenderer.class)
public abstract class DebugRendererMixin {
    @Inject(at = @At(value = "TAIL"), method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;DDD)V")
    private void Irender(MatrixStack matrices, VertexConsumerProvider.Immediate vertexConsumers, double cameraX, double cameraY, double cameraZ, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (Client.showBiome && !client.hasReducedDebugInfo()) {
            RenderSystem.color4f(0, 0, 1, 0.25f);
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableCull();
            RenderSystem.disableTexture();

            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder buffer = tessellator.getBuffer();

            int viewDist = client.options.viewDistance >> 1;
            ClientWorld world = client.world;
            Entity entity = client.gameRenderer.getCamera().getFocusedEntity();
            BlockPos blockPos = entity.getBlockPos();
            int chunkX = blockPos.getX() >> 4;
            int chunkY = blockPos.getY() >> 4;
            int chunkZ = blockPos.getZ() >> 4;

            buffer.begin(7, VertexFormats.POSITION);
            for (int chunkJ = -viewDist; chunkJ <= viewDist; ++chunkJ) {
                int y = (chunkY + chunkJ) << 4;

                if (0 <= y && y < 256)
                    for (int chunkK = -viewDist; chunkK <= viewDist; ++chunkK) {
                        int z = (chunkZ + chunkK) << 4;

                        for (int chunkI = -viewDist; chunkI <= viewDist; ++chunkI) {
                            int x = (chunkX + chunkI) << 4;

                            for (int j : Client.biomePerChunk)
                                for (int k : Client.biomePerChunk)
                                    for (int i : Client.biomePerChunk) {
                                        double x1 = x + i - cameraX;
                                        double y1 = y + j - cameraY;
                                        double z1 = z + k - cameraZ;
                                        double x2 = x1 + 4;
                                        double y2 = y1 + 4;
                                        double z2 = z1 + 4;
                                        int biomeX = (x + i) >> 2;
                                        int biomeY = (y + j) >> 2;
                                        int biomeZ = (z + k) >> 2;
                                        Biome biome = world.getBiomeForNoiseGen(biomeX, biomeY, biomeZ);

                                        if (!biome.equals(world.getBiomeForNoiseGen(biomeX, biomeY - 1, biomeZ))) {
                                            buffer.vertex(x1, y1, z1).next();
                                            buffer.vertex(x2, y1, z1).next();
                                            buffer.vertex(x2, y1, z2).next();
                                            buffer.vertex(x1, y1, z2).next();
                                        }
                                        if (!biome.equals(world.getBiomeForNoiseGen(biomeX, biomeY + 1, biomeZ))) {
                                            buffer.vertex(x2, y2, z2).next();
                                            buffer.vertex(x2, y2, z1).next();
                                            buffer.vertex(x1, y2, z1).next();
                                            buffer.vertex(x1, y2, z2).next();
                                        }
                                        if (!biome.equals(world.getBiomeForNoiseGen(biomeX, biomeY, biomeZ - 1))) {
                                            buffer.vertex(x1, y1, z1).next();
                                            buffer.vertex(x1, y2, z1).next();
                                            buffer.vertex(x2, y2, z1).next();
                                            buffer.vertex(x2, y1, z1).next();
                                        }
                                        if (!biome.equals(world.getBiomeForNoiseGen(biomeX, biomeY, biomeZ + 1))) {
                                            buffer.vertex(x2, y2, z2).next();
                                            buffer.vertex(x1, y2, z2).next();
                                            buffer.vertex(x1, y1, z2).next();
                                            buffer.vertex(x2, y1, z2).next();
                                        }
                                        if (!biome.equals(world.getBiomeForNoiseGen(biomeX - 1, biomeY, biomeZ))) {
                                            buffer.vertex(x1, y1, z1).next();
                                            buffer.vertex(x1, y1, z2).next();
                                            buffer.vertex(x1, y2, z2).next();
                                            buffer.vertex(x1, y2, z1).next();
                                        }
                                        if (!biome.equals(world.getBiomeForNoiseGen(biomeX + 1, biomeY, biomeZ))) {
                                            buffer.vertex(x2, y2, z2).next();
                                            buffer.vertex(x2, y1, z2).next();
                                            buffer.vertex(x2, y1, z1).next();
                                            buffer.vertex(x2, y2, z1).next();
                                        }
                                    }
                        }
                    }

            }
            tessellator.draw();
        }
    }
}