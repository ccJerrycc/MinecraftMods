package mc212fix.mixin;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin {
    @Redirect(at = @At(value = "INVOKE", target = "net/minecraft/server/MinecraftServer.isDedicated ()Z"), method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z")
    private boolean RisDedicated(MinecraftServer server) {
        return true;
    }

    @Redirect(at = @At(value = "INVOKE", target = "net/minecraft/server/network/ServerPlayerEntity.isPvpEnabled ()Z"), method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z")
    private boolean RisPvpEnabled(ServerPlayerEntity instance) {
        return true;
    }
}