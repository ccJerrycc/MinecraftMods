package stonewall;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.WallBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class Main implements ModInitializer {
    @Override
    public void onInitialize() {
        final Identifier STONE_WALL_ID = new Identifier("stone_wall");
        final Block STONE_WALL = Registry.register(Registry.BLOCK, STONE_WALL_ID, new WallBlock(AbstractBlock.Settings.copy(Blocks.STONE)));
        final BlockItem STONE_WALL_ITEM = new BlockItem(STONE_WALL, new Item.Settings().group(ItemGroup.DECORATIONS));

        Item.BLOCK_ITEMS.put(STONE_WALL, STONE_WALL_ITEM);
        Registry.register(Registry.ITEM, STONE_WALL_ID, (Item) STONE_WALL_ITEM);
    }
}