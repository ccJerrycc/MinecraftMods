package tickspawnertag.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.world.MobSpawnerLogic;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(MobSpawnerLogic.class)
public abstract class MobSpawnerLogicMixin {
    @Redirect(at = @At(value = "INVOKE", target = "net/minecraft/world/World.isPlayerInRange (DDDD)Z"), method = "isPlayerInRange()Z")
    private boolean RisPlayerInRange(World world, double x, double y, double z, double range) {
        for (PlayerEntity playerEntity : world.getPlayers()) {
            if (!EntityPredicates.EXCEPT_SPECTATOR.test(playerEntity) || !(world.isClient || playerEntity.getScoreboardTags().contains("tickSpawner")) || !EntityPredicates.VALID_LIVING_ENTITY.test(playerEntity)) continue;
            double d = playerEntity.squaredDistanceTo(x, y, z);
            if (!(range < 0.0) && !(d < range * range)) continue;
            return true;
        }
        return false;
    }
}