package tickspawnertag.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.MobSpawnerLogic;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(MobSpawnerLogic.class)
public abstract class MobSpawnerLogicMixin {
    @Redirect(at = @At(value = "INVOKE", target = "net/minecraft/world/MobSpawnerLogic.isPlayerInRange (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z"), method = "serverTick(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/BlockPos;)V")
    private boolean RisPlayerInRange(MobSpawnerLogic ins, World world, BlockPos pos) {
        double x = ((double) pos.getX()) + 0.5;
        double y = ((double) pos.getY()) + 0.5;
        double z = ((double) pos.getZ()) + 0.5;
        int range = ((IMobSpawnerLogicMixin) ins).getRequiredPlayerRange();

        for (PlayerEntity playerEntity : world.getPlayers()) {
            if (!EntityPredicates.EXCEPT_SPECTATOR.test(playerEntity) || !playerEntity.getScoreboardTags().contains("tickSpawner") || !EntityPredicates.VALID_LIVING_ENTITY.test(playerEntity)) continue;
            double d = playerEntity.squaredDistanceTo(x, y, z);
            if (!(range < 0.0) && !(d < range * range)) continue;
            return true;
        }
        return false;
    }
}