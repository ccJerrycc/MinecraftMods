package paintings;

import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.decoration.painting.PaintingMotive;
import net.minecraft.util.registry.Registry;

public class Main implements ModInitializer {
    @Override
    public void onInitialize() {
        Registry.register(Registry.PAINTING_MOTIVE, "custom-paintings:example", new PaintingMotive(16, 16));
    }
}