package signtextextended.mixin;

import net.minecraft.network.packet.c2s.play.UpdateSignC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(UpdateSignC2SPacket.class)
public abstract class UpdateSignC2SPacketMixin {
    @ModifyConstant(constant = @Constant(intValue = 384), method = "<init>(Lnet/minecraft/network/PacketByteBuf;)V")
    private int MCUpdateSignC2SPacket(int maxLength) {
        return 32767;
    }
}