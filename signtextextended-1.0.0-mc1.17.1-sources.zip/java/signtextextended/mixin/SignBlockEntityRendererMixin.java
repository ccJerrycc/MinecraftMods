package signtextextended.mixin;

import net.minecraft.client.render.block.entity.SignBlockEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(SignBlockEntityRenderer.class)
public abstract class SignBlockEntityRendererMixin {
    @ModifyConstant(constant = @Constant(intValue = 90), method = "method_32159(Lnet/minecraft/text/Text;)Lnet/minecraft/text/OrderedText;")
    private int MCmethod_32159(int c90) {
        return 2147483647;
    }
}