package signtextextended.mixin;

import net.minecraft.client.gui.screen.ingame.SignEditScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(SignEditScreen.class)
public abstract class SignEditScreenMixin {
    @ModifyConstant(constant = @Constant(intValue = 90), method = "method_27611(Ljava/lang/String;)Z")
    private int MCmethod_27611(int c90) {
        return 2147483647;
    }
}