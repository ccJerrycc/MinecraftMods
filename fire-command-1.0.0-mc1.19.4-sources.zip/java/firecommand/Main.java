package firecommand;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.Entity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;

public class Main implements ModInitializer {
    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                CommandManager.literal("fire").requires(source -> source.hasPermissionLevel(2)).
                        then(CommandManager.argument("target", EntityArgumentType.entity()).
                                then(CommandManager.literal("for").
                                    then(CommandManager.argument("seconds", IntegerArgumentType.integer()).executes(context -> {
                                        Entity target = EntityArgumentType.getEntity(context, "target");
                                        int seconds = IntegerArgumentType.getInteger(context, "seconds");

                                        target.setOnFireFor(seconds);
                                        context.getSource().sendFeedback(Text.translatable("commands.fire.for.success", target.getName(), seconds), false);

                                        return 1;
                                    }))).
                                then(CommandManager.literal("get").executes(context -> {
                                    Entity target = EntityArgumentType.getEntity(context, "target");
                                    int ticks = target.getFireTicks();

                                    context.getSource().sendFeedback(Text.translatable("commands.fire.get.success", target.getName(), ticks), false);

                                    return ticks;
                                })).
                                then(CommandManager.literal("set").
                                    then(CommandManager.argument("ticks", IntegerArgumentType.integer()).executes(context -> {
                                        Entity target = EntityArgumentType.getEntity(context, "target");
                                        int ticks = IntegerArgumentType.getInteger(context, "ticks");

                                        target.setFireTicks(ticks);
                                        context.getSource().sendFeedback(Text.translatable("commands.fire.set.success", target.getName(), ticks), false);

                                        return 1;
                                    })))))
        );
    }
}