package mc47660fix.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.MutableWorldProperties;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.function.Supplier;

@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin extends World {
    protected ClientWorldMixin(MutableWorldProperties properties, RegistryKey<World> registryRef, DynamicRegistryManager registryManager, RegistryEntry<DimensionType> dimensionEntry, Supplier<Profiler> profiler, boolean isClient, boolean debugWorld, long biomeAccess, int maxChainedNeighborUpdates) {
        super(properties, registryRef, registryManager, dimensionEntry, profiler, isClient, debugWorld, biomeAccess, maxChainedNeighborUpdates);
    }

    @ModifyExpressionValue(at = @At(value = "INVOKE", target = "net/minecraft/client/world/ClientWorld.getBlockParticle ()Lnet/minecraft/block/Block;"), method = "doRandomBlockDisplayTicks(III)V")
    private Block MCdoRandomBlockDisplayTicks(Block og, int centerX, int centerY, int centerZ) {
        BlockPos.Mutable mutable = new BlockPos.Mutable();

        for (int i = -32; i <= 32; ++i)
            for (int j = -32; j <= 32; ++j)
                for (int k = -32; k <= 32; ++k) {
                    int x = centerX + i;
                    int y = centerY + j;
                    int z = centerZ + k;
                    BlockState blockState = this.getBlockState(mutable.set(x, y, z));

                    if (og == blockState.getBlock())
                        this.addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK_MARKER, blockState), (double) x + 0.5, (double) y + 0.5, (double) z + 0.5, 0.0, 0.0, 0.0);
                }

        return null;
    }
}